package edu.uw.aad.mzm.solution.homework2;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;


public class ConfirmationActivity extends ActionBarActivity {

    private String mName;
    private String mEmail;
    private boolean mReceiveNewsletter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        Bundle extras = getIntent().getExtras();
        mName = extras.getString("name");
        mEmail = extras.getString("email");
        mReceiveNewsletter = extras.getBoolean("newsletter");

        TextView textViewName = (TextView)findViewById(R.id.textViewName);
        TextView textViewEmail = (TextView)findViewById(R.id.textViewEmail);
        TextView textViewNewsLetter = (TextView)findViewById(R.id.textViewConsent);

        // Name
        textViewName.setText(mName);
        // Email
        textViewEmail.setText(mEmail);
        // Whether or not to sign up to receive newsletter
        if(mReceiveNewsletter) {
            textViewNewsLetter.setText("Yes");
        } else {
            textViewNewsLetter.setText("No");
        }
    }

}
