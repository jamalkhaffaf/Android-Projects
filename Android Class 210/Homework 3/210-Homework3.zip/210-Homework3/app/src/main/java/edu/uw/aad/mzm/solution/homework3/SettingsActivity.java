package edu.uw.aad.mzm.solution.homework3;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * This activity hosts {@link SettingsFragment}
 */
public class SettingsActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Add SettingsFragment to a container view (R.id.frag_container) in activity UI
        getFragmentManager().beginTransaction().add(R.id.frag_container, new SettingsFragment()).commit();
    }

}
