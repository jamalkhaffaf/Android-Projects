package edu.uw.aad.mzm.solution.homework3;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;

/**
 * Created by Margaret on 2/15/2015
 *
 * A fragment that shows user a settings screen
 * This fragment is hosted by {@link SettingsActivity}
 */
public class SettingsFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {

    // Required public empty constructor
    public SettingsFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load preferences from the settings.xml
        addPreferencesFromResource(R.xml.settings);

    }


    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        Preference preference = findPreference(key);

        if(key.equals(getString(R.string.pref_key_text_size))) {
            String textSizeStr = sharedPreferences.getString(key, "") + "sp";
            preference.setSummary(textSizeStr);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Register OnSharedPreferenceChangeListener
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        initSummary();
    }

    /**
     * Initialize preference summary
     */
    private void initSummary() {

        SharedPreferences prefs = getPreferenceManager().getSharedPreferences();
        Preference preference = findPreference(getString(R.string.pref_key_text_size));
        // Default summary: "Please enter a text size between 14 - 26sp."
        String defaultSummary = getString(R.string.pref_default_summary_text_size);
        // Current summary based on user selection
        String currentSummary = prefs.getString(getString(R.string.pref_key_text_size), "");
        if (!currentSummary.isEmpty()) {
            // Set summary as user selection if not empty
            preference.setSummary(currentSummary + "sp");
        } else {
            // Otherwise display the default summary
            preference.setSummary(defaultSummary);
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        // Unregister OnSharedPreferenceChangeListener
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }
}
