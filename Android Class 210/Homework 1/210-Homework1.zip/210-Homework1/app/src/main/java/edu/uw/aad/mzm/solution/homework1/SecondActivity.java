package edu.uw.aad.mzm.solution.homework1;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class SecondActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

}
