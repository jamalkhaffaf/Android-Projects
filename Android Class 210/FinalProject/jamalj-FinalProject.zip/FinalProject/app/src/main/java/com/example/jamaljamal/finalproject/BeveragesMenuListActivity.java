package com.example.jamaljamal.finalproject;

import android.content.Context;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class BeveragesMenuListActivity extends ActionBarActivity {

    //Custom object to support custom ArrayAdapter
    public class MenuAPI{
        public String menuName;

        public MenuAPI(String menuName){
            this.menuName = menuName;
        }
    }

    //Custom ArrayAdapter for the list of "Entrees"
    private class MenuAPIAdapter extends ArrayAdapter<MenuAPI> {

        private ArrayList<MenuAPI> mMenuAPIs;
        private MenuAPIAdapter(Context context, int resource, ArrayList<MenuAPI> data){
            super(context, resource, data);
            mMenuAPIs = data;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            View view = convertView;
            if (view == null){
                LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.menu_list_item, null);
            }

            MenuAPI menuAPI = mMenuAPIs.get(position);

            if(menuAPI != null){
                TextView textViewName = (TextView) findViewById(R.id.textViewMenuName);

                if (textViewName != null){
                    textViewName.setText(menuAPI.menuName);
                }
            }
            return view;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beverages_menu_list);

        ArrayList<MenuAPI> mMenuAPIs = new ArrayList<MenuAPI>();

        mMenuAPIs.add(new MenuAPI("Wine"));
        mMenuAPIs.add(new MenuAPI("Beer"));
        mMenuAPIs.add(new MenuAPI("Whiskey"));

        ListView listView = (ListView)findViewById(R.id.listViewBeveragesMenu);
        MenuAPIAdapter menuAPIAdapter = new MenuAPIAdapter(this, R.layout.menu_list_item, mMenuAPIs);
        listView.setAdapter(menuAPIAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_beverages_menu_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
