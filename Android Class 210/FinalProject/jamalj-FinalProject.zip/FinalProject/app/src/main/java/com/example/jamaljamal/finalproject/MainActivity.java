package com.example.jamaljamal.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;


public class MainActivity extends ActionBarActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // the commented lines are left for future development

        findViewById(R.id.imageButtonEntrees).setOnClickListener(this);
        findViewById(R.id.imageButtonBeverages).setOnClickListener(this);
    //This button will be connected to a push notification service
    //to let customers know about special offers and happy hours
        //findViewById(R.id.imageButtonNews).setOnClickListener(this);
    //This will button will allow customers to use their phone camera to take pictures
    //for different dishes they had. In order to keep track of what they ate previously
    //or to share those moments with their family and freinds.
        //findViewById(R.id.imageButtonGallary).setOnClickListener(this);
        findViewById(R.id.imageButtonLocation).setOnClickListener(this);
        findViewById(R.id.imageButtonContactUs).setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();

        switch (v.getId()){
            case R.id.imageButtonEntrees:
                intent.setClass(this, EntreesMenuListActivity.class);
                break;
            case R.id.imageButtonBeverages:
                intent.setClass(this, BeveragesMenuListActivity.class);
                break;
            case R.id.imageButtonNews:
                break;
            case R.id.imageButtonGallary:
                break;
            case R.id.imageButtonLocation:
                intent.setClass(this, LocationActivity.class);
                break;
            case R.id.imageButtonContactUs:
                intent.setClass(this, ContactUsActivity.class);
                break;
        }
        startActivity(intent);
    }
}
