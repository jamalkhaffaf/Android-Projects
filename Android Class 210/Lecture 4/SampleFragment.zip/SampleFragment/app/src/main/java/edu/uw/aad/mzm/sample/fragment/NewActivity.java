package edu.uw.aad.mzm.sample.fragment;

import android.app.Activity;
import android.os.Bundle;

/**
 * A new activity created during class on 2/2/2015
 * Hosting
 */
public class NewActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
    }
}
