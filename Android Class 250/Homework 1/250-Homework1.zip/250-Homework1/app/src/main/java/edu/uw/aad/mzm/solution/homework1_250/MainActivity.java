package edu.uw.aad.mzm.solution.homework1_250;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;

import edu.uw.aad.mzm.solution.homework1_250.ConfirmationActivity;
import edu.uw.aad.mzm.solution.homework2.R;

/**
 * Created by Margaret on 4/15/2015
 * Android 250 - Winter 2015 - Homework 1 Solution
 */
public class MainActivity extends ActionBarActivity {

    private EditText mEditTextEmail;
    private EditText mEditTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the views by ids
        mEditTextEmail = (EditText) findViewById(R.id.editTextEmail);

        mEditTextPassword = (EditText) findViewById(R.id.editTextPassword);

        // Set OnClickListener on the submit button
        findViewById(R.id.buttonSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (formIsValid()) {
                    gotoConfirmationScreen();
                }
            }
        });
    }

    /**
     * Validate each input field
     * @return
     */
    private boolean formIsValid() {

        // check if email is entered
        if (TextUtils.isEmpty(getInput(mEditTextEmail))) {
            mEditTextEmail.setError("Please enter an email");
            return false;
            // check if email is in valid format
        } else if (!Patterns.EMAIL_ADDRESS.matcher(getInput(mEditTextEmail)).matches()) {
            mEditTextEmail.setError("Please enter a valid email");
            return false;
        }

        // check if name is entered
        if (TextUtils.isEmpty(getInput(mEditTextPassword))) {
            mEditTextPassword.setError("Please enter a password");
            return false;
        }

        return true;
    }

    /**
     * Get the user input in EditText
     * @param editText
     * @return
     */
    private String getInput(EditText editText) {
        return editText.getText().toString().trim();
    }

    /**
     * Go to the confirmation screen that displays user input
     */
    private void gotoConfirmationScreen() {

        Intent intent = new Intent(this, ConfirmationActivity.class);
        intent.putExtra("email", mEditTextEmail.getText().toString());
        intent.putExtra("password", mEditTextPassword.getText().toString());
        startActivity(intent);

    }

}
