package edu.uw.aad.mzm.solution.homework1_250;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

import edu.uw.aad.mzm.solution.homework2.R;

public class ConfirmationActivity extends ActionBarActivity {

    private String mEmail;
    private String mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        Bundle extras = getIntent().getExtras();
        mEmail = extras.getString("email");
        mPassword = extras.getString("password");

        TextView textViewPassword = (TextView)findViewById(R.id.textViewName);
        TextView textViewEmail = (TextView)findViewById(R.id.textViewEmail);

        // Email
        textViewEmail.setText(mEmail);
        // Password
        textViewPassword.setText(mPassword);
    }

}
